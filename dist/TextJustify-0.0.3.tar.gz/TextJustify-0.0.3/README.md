This is the initial release of Text Justify package.
Soon the details document will be available here.
